Pixel UI Pack (1.16.5, pack_format 6)
------------------------------------
CustomModelData on PAPER:

7001 = 포켓볼
7002 = 에메랄드
7003 = 사파이어
7004 = 루비
7005 = 다이아
7006 = 세븐
7201 = 화살표(UP)
7202 = 화살표(DOWN)
7300..7309 = 숫자 0..9

체스트 GUI:
- generic_54.png / generic_27.png : 기본(카지노) 브라운&그린
- shop_54.png : 하늘색 백화점 톤
- auction_54.png : 다크 & 골드
- stock_54.png : 모던 그레이/블루
(바닐라 제한상 기본 적용은 generic_XX 만 되므로, 다른 테마는 맵/오버레이로 사용하세요.)

