
Arclint All UI Pack (1.16.5)
============================

Included:
- Textures for custom GUI frames (not overriding vanilla):
  assets/minecraft/textures/gui/arclintui/{auction,shop,slot,updown,stock}.png

- CustomModelData overrides on paper item:
  13101 -> slot_pokeball
  13102 -> slot_emerald
  13103 -> slot_sapphire
  13104 -> slot_ruby
  13105 -> slot_diamond
  13106 -> slot_seven
  13200..13209 -> ud_digit_0..9
  13300 -> ud_btn_up
  13301 -> ud_btn_down

Usage (Spigot 1.16.5):
----------------------
ItemStack paper = new ItemStack(Material.PAPER);
ItemMeta meta = paper.getItemMeta();
meta.setCustomModelData(13106); // seven icon
meta.setDisplayName(" ");
paper.setItemMeta(meta);

